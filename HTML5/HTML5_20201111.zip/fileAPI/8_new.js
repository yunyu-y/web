function doFirst(){
    //先跟HTML畫面產生關聯,再建事件聆聽功能
    document.getElementById('theFile').onchange = fileChange;
}
function fileChange(){
    let file = document.getElementById('theFile').files[0];
    // console.log(file);
    let message = '';
    message += `檔案名稱: ${file.name}\n`;
    message += `檔案大小: ${file.size} byte(s)\n`;
    message += `檔案格式: ${file.type}\n`;
    message += `檔案最後更新日期: ${file.lastModifiedDate}\n`;

    document.getElementById('fileInfo').value = message;

    //========
    let readFile = new FileReader();
    readFile.readAsDataURL(file);
    readFile.addEventListener('load',function(){
        let myMovie = document.getElementById('myMovie');
        myMovie.src = readFile.result;
        // myMovie.controls = 'controls';
        myMovie.controls = true;
        myMovie.width = 520;
        myMovie.poster = '../../images/Shinnosuke/Shinnosuke7.png';
    });
}
window.addEventListener('load',doFirst);