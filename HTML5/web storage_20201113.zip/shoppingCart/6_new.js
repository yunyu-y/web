﻿let storage = sessionStorage;
function doFirst(){
   
}
window.addEventListener('load', doFirst);